# STAT/CS 287
# HW 01
#
# Name: Sandhya
# Date: 09/08/2017


print("******************** HW01: Problem 1/3 ********************")

def similarity(A,B):
    """Define two sets A and B. Calculate their cordinality and 
    find out the similarity between two sets. Similarity is define by 
    similarity(A,B)=|A∩B|/|A∪B|
    """
    #Cardinality of set A
    cardinality_A = len(A.union(B))
    
    #Cardinality of set B
    cardinality_B = len(A.intersection(B))
    
    #find similarity between A and B
    similarity_AB = cardinality_B/cardinality_A
    
    #retrun the similarity value
    return similarity_AB


### Test inputs to validate the function ###

A = {1,2,3,4,5}
B = {2,3,4,7}
result = similarity(A,B)
print(result)

A = {6,7,8}
B = {6}
result = similarity(A,B)
print(result)

A = {5,4,7,8}
B = {0,1,2}
result = similarity(A,B)
print(result)



print("******************** HW01: Problem 2/3 ********************")

import random

def coin_flip(p):
    """Generate random numbers from range 0-1. Compare the number with the given 
    probablity 'p' and check whether it is a head or tail. Store head and tail in
    the list
    """
    #Number of coin flip
    numberOfCoinFlip = 10;
    
    #initialize a list that would contain the result (H or T)
    coinList = []
    
    #loop over the total range of coin flip. random.random would generate 
    # a random number between 0-1. if number is less than given p then it 
    #is head else it is a tail. Store the result in a list and return the list.
    
    for number in range(numberOfCoinFlip):
        if random.random() < p :
            coinList.append('H')
        else:
            coinList.append('T')
    return coinList



     
def run_statistics(coin_list):
    """This function will take the coin_list. It will calculate the head run 
     and store in a list. The length of the list is the number of head runs 
     in the list
    """
    ## counter will count the head in each run and save the result in a list 'runs'
    counter=0
    runs =[]
    run_dict = {}
    
    #loop over every item in coin_list and count the number of heads. If tail occurs, 
    #re-initialize the counter to 0, in order to find the runs of Head.
    for item in coin_list:
        if(item == 'H'):
            counter+=1
        else:
            if counter != 0:
                runs.append(counter)
                counter = 0
    #this condition is for the case when the last element of list is 'H' in that case
    #else condition will not be called and the last run of head will not be printed.
    #this trick will count the last run of head.
    if(coin_list[-1] == 'H'):
        runs.append(counter)
        
    #loop over each item in runs List and check whether it has occured before or not
    
    for item in runs:
        if item not in run_dict:
            #if word is occuring first time. the count = 1
            run_dict["Number of run of length " + str(item)]=1
        else:
            #if not first time, then increment the value of the word
            run_dict["Number of run of length " + str(item)]+=1
    return run_dict



### Test run for probablity 0.2,0.4,0.6 and 0.8 and run statistics in each###

result_list = coin_flip(0.2)
print(result_list)
head_run_list = run_statistics(result_list)
print(head_run_list)
#print('The are %d head runs of length: ' % len(head_run_list), *head_run_list,sep=' ')
print("\n")


result_list = coin_flip(0.4)
print(result_list)
head_run_list = run_statistics(result_list)
print(head_run_list)
#print('The are %d head runs of length: ' % len(head_run_list), *head_run_list,sep=' ')
print("\n")


result_list = coin_flip(0.6)
print(result_list)
head_run_list = run_statistics(result_list)
print(head_run_list)
#print('The are %d head runs of length: ' % len(head_run_list), *head_run_list,sep=' ')
print("\n")


result_list = coin_flip(0.8)
print(result_list)
head_run_list = run_statistics(result_list)
print(head_run_list)
print("\n")




print("******************** HW01: Problem 3/3 ********************")

import urllib.request
from string import punctuation

def words_of_book():
    """Download `A tale of two cities` from Project Gutenberg. Return a list of
    words. Punctuation has been removed and upper-case letters have been
    replaced with lower-case.
    """

    url = "http://www.gutenberg.org/files/98/98.txt"
    req = urllib.request.urlopen(url)
    charset = req.headers.get_content_charset()
    raw = req.read().decode(charset)

    raw = raw[750:] # The first 750 or so characters are not part of the book.

    # Loop over every character in the string, keep it only if it is NOT
    # punctuation:
    exclude = set(punctuation) # Keep a set of "bad" characters.
    list_letters_noPunct = [ char for char in raw if char not in exclude ]

    # Now we have a list of LETTERS, *join* them back together to get words:
    text_noPunct = "".join(list_letters_noPunct)
    # (http://docs.python.org/2/library/stdtypes.html#str.join)

    # Split this big string into a list of words:
    list_words = text_noPunct.strip().split()

    # Convert to lower-case letters:
    list_words = [ word.lower() for word in list_words ]
    
    return list_words



def word_freq(wordlist,topCommonWords):
    """This function takes wordlist from previous function and count the frequency of 
    each word and save it in a dictionary in key value form. Where key is a word and value is
    number of occurence of that word. It also sorts the dictionary on value and store the 
    sorted dictionary pairs in list of tuples. It then display the top common words.
    """
    
    #initialize dictionary
    wordfreq_dict = {}
    
    #loop over each word in wordlist and check whether it has occured before or not
    for word in wordlist:
        if word not in wordfreq_dict:
            #if word is occuring first time. the count = 1
            wordfreq_dict[word]=1
        else:
            #if not first time, then increment the value of the word
            wordfreq_dict[word]+=1
    
    
    # dictionary items are sorted in list of tuples
    sorted_list = sorted(wordfreq_dict.items(), key=lambda x:x[1])
    #sorted_list = sorted(wordfreq_dict.items(),key=operator.itemgetter(1))
    
    #list is reversed to get the most common words on top
    sorted_list.reverse()
    #print the list of tuples
    #print(sorted_list)
    
    #store top words in a list
    topCommonWordList = []
    
    # The variable topCommonWords would enable user
    #to pass how many common words she wants to store in the list
     
    commonWordCount =0;
    for tuples in sorted_list:
       # print(tuples)
        topCommonWordList.append(tuples)
        commonWordCount+=1
        if commonWordCount > topCommonWords:
            break
    print("top " + str(topCommonWords) + " most common words are:")
    print("\n")
    return topCommonWordList
    #return sorted_dict;



### test run the function to get the frequency of each word and display top most common words ###

wordList = words_of_book();
topCommonWords = word_freq(wordList,10)
print(topCommonWords)

